a = input()
k = int(input())
print(a*k)