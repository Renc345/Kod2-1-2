a = int(input())
if a % 5 == 0:
    b = a // 5
else:
    b = (a // 5) * 5
output = "a" * b
print(output)