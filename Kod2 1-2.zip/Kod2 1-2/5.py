a = input()
b = int(input())
for i in range(1, b + 1):
    if i > 1 and i < b:
        print(a*b)
