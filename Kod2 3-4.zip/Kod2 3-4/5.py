a = input()
for elem in reversed(a):
    print(elem)