print(*input(), sep="\n")
