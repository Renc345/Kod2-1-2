a = input().split()
for i in range(1, len(a)):
    if not len(a[i]) - len(a[i - 1]) == 1 or a[i][0] != a[i - 1][-1]:
        print(i)
        break
else:
    print(len(a))